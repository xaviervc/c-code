If you are reading this then if you try to compile the program with report.c
it will not work. I did not have enough time to figure out a way to keep track
of everything. Although my code does work if you compile replace.c traversal.c and
text.c! The only thing I didn't implement was the report.

Please do not be too harsh when grading me! :D

Regards, Xavier Vani-Charron
Student ID: 27055838
