/*traversal.h*/

void traverse();
